"""
.. click:: launch.cli.bin:entry_point
   :prog: scale-launch
   :nested: full
"""
