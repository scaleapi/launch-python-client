from enum import Enum, auto


class Runtime(Enum):
    SYNC = auto()
    ASYNC = auto()
