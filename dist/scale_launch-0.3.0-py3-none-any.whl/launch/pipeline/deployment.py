from dataclasses import dataclass


@dataclass
class Deployment:
    """Base deployment class"""
