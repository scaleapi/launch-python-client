ENDPOINT_PATH = "endpoints"
MODEL_BUNDLE_SIGNED_URL_PATH = "model_bundle_upload"
BATCH_TASK_INPUT_SIGNED_URL_PATH = "batch_task_input_upload"
ASYNC_TASK_PATH = "task_async"
ASYNC_TASK_RESULT_PATH = "task/result"
SYNC_TASK_PATH = "task_sync"
BATCH_TASK_PATH = "batch_job"
BATCH_TASK_RESULTS_PATH = "batch_job"
RESULT_PATH = "result"
SCALE_LAUNCH_ENDPOINT = "https://api.scale.com/v1/hosted_inference"

DEFAULT_NETWORK_TIMEOUT_SEC = 120
